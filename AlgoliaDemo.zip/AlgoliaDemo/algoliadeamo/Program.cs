﻿using Algolia.Search;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Reflection;

namespace algoliadeamo
{
    public class Program
    {
        public static void Main(string[] args)
        {

            AlgoliaClient client = new AlgoliaClient("T91QRB3KF1", "ed488715921b3e16dad0aa9962490be4");
            string[] filePaths = Directory.GetFiles(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + @"\JsonDataSet");
            Console.WriteLine("Please wait while records are added to index");
            foreach(var filePath in filePaths) {
                Index index = client.InitIndex("index_"+Path.GetFileName(filePath));
                var reader = ReadAsLines(filePath);
                var data = new DataTable();
                //this assume the first record is filled with the column names
                var headers = reader.First().Split('\t');
                foreach (var header in headers)
                    data.Columns.Add(header);

                var records = reader.Skip(1);
                foreach (var record in records)
                    data.Rows.Add(record.Split('\t'));
                foreach (DataRow row in data.Rows)
                {
                    int i = 0;
                    Dictionary<string, string> CityObject = new Dictionary<string, string>();
                    foreach (DataColumn column in data.Columns)
                    {
                        CityObject[column.ColumnName] = row.ItemArray[i++].ToString();
                    }
                    index.AddObject(CityObject);
                }                
            }
        }

        public static IEnumerable<string> ReadAsLines(string filename)
        {
            using (var reader = new StreamReader(filename))
                while (!reader.EndOfStream)
                    yield return reader.ReadLine();
        }

    }
}
